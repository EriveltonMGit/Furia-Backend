const express = require("express")
const router = express.Router()
const {
  getProfile,
  updatePersonalInfo,
  updateInterests,
  updateActivities,
  updateSocialConnections,
  updateVerificationStatus,
} = require("../controllers/profile.controller")
const { protect, authorize } = require("../middleware/auth.middleware")

// Todas as rotas são protegidas
router.use(protect)

router.get("/", getProfile)
router.put("/personal-info", updatePersonalInfo)
router.put("/interests", updateInterests)
router.put("/activities", updateActivities)
router.put("/social-connections", updateSocialConnections)

// Apenas administradores podem atualizar o status de verificação
router.put("/verification-status", authorize("admin"), updateVerificationStatus)

module.exports = router
