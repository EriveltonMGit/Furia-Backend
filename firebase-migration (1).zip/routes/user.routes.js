const express = require("express")
const router = express.Router()
const { updatePassword, updateEmail, deleteAccount } = require("../controllers/user.controller")
const { protect } = require("../middleware/auth.middleware")

// Todas as rotas são protegidas
router.use(protect)

router.put("/password", updatePassword)
router.put("/email", updateEmail)
router.delete("/", deleteAccount)

module.exports = router
