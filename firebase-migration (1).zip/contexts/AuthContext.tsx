"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import {
  login as apiLogin,
  register as apiRegister,
  logout as apiLogout,
  getCurrentUser,
  isAuthenticated,
} from "../services/auth.service"
import { useRouter } from "next/navigation"

// Tipos
interface User {
  id: string
  name: string
  email: string
  role: string
}

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  checkAuth: () => Promise<boolean>
}

// Criar o contexto
const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Provider
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  // Verificar autenticação ao carregar
  useEffect(() => {
    const checkUserAuth = async () => {
      try {
        const isUserAuthenticated = await isAuthenticated()
        if (isUserAuthenticated) {
          const userData = await getCurrentUser()
          setUser(userData)
        }
      } catch (error) {
        console.error("Erro ao verificar autenticação:", error)
        setUser(null)
      } finally {
        setLoading(false)
      }
    }

    checkUserAuth()
  }, [])

  // Login
  const login = async (email: string, password: string) => {
    try {
      const response = await apiLogin({ email, password })
      setUser(response.user)
      return response
    } catch (error) {
      console.error("Erro no login:", error)
      throw error
    }
  }

  // Registro
  const register = async (name: string, email: string, password: string) => {
    try {
      const response = await apiRegister({ name, email, password })
      setUser(response.user)
      return response
    } catch (error) {
      console.error("Erro no registro:", error)
      throw error
    }
  }

  // Logout
  const logout = async () => {
    try {
      await apiLogout()
      setUser(null)
      router.push("/login")
      router.refresh() // Importante para atualizar o estado da sessão
    } catch (error) {
      console.error("Erro no logout:", error)
      throw error
    }
  }

  // Verificar autenticação
  const checkAuth = async () => {
    try {
      const isUserAuthenticated = await isAuthenticated()
      if (isUserAuthenticated && !user) {
        const userData = await getCurrentUser()
        setUser(userData)
      }
      return isUserAuthenticated
    } catch (error) {
      console.error("Erro ao verificar autenticação:", error)
      setUser(null)
      return false
    }
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, checkAuth }}>
      {children}
    </AuthContext.Provider>
  )
}

// Hook para usar o contexto
export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth deve ser usado dentro de um AuthProvider")
  }
  return context
}
