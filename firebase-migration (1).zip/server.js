const express = require("express")
const cors = require("cors")
const bodyParser = require("body-parser")
const dotenv = require("dotenv")
const morgan = require("morgan")
const { connectDB } = require("./config/firebase")
const cookieParser = require("cookie-parser")

// Carregar variáveis de ambiente
dotenv.config()

// Inicializar app Express
const app = express()

// Middleware
app.use(cookieParser())
app.use(
  cors({
    origin: "http://localhost:3000", // Ou domínio de produção
    credentials: true, // Isso é ESSENCIAL para cookies
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  }),
)

app.use(bodyParser.json())
app.use(morgan("dev"))

// Conectar ao banco de dados
connectDB()

// Rotas
app.use("/api/auth", require("./routes/auth.routes"))
app.use("/api/users", require("./routes/user.routes"))
app.use("/api/profile", require("./routes/profile.routes"))

// Rota de teste
app.get("/", (req, res) => {
  res.json({ message: "API do FURIA Fan Platform funcionando com Firebase!" })
})

// Middleware de tratamento de erros
app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).json({
    success: false,
    message: "Erro no servidor",
    error: process.env.NODE_ENV === "development" ? err.message : undefined,
  })
})

// Iniciar servidor
const PORT = process.env.PORT || 5000
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`)
})
