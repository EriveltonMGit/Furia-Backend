// Validar email
exports.validateEmail = (email) => {
  const re =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
  return re.test(String(email).toLowerCase())
}

// Validar senha
exports.validatePassword = (password) => {
  // Pelo menos 8 caracteres, incluindo pelo menos uma letra e um número
  const re = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/
  return re.test(String(password))
}

// Validar CPF
exports.validateCPF = (cpf) => {
  cpf = cpf.replace(/[^\d]/g, "")

  if (cpf.length !== 11) return false

  // Verificar se todos os dígitos são iguais
  if (/^(\d)\1+$/.test(cpf)) return false

  // Validação do primeiro dígito verificador
  let sum = 0
  for (let i = 0; i < 9; i++) {
    sum += Number.parseInt(cpf.charAt(i)) * (10 - i)
  }
  let remainder = 11 - (sum % 11)
  if (remainder === 10 || remainder === 11) remainder = 0
  if (remainder !== Number.parseInt(cpf.charAt(9))) return false

  // Validação do segundo dígito verificador
  sum = 0
  for (let i = 0; i < 10; i++) {
    sum += Number.parseInt(cpf.charAt(i)) * (11 - i)
  }
  remainder = 11 - (sum % 11)
  if (remainder === 10 || remainder === 11) remainder = 0
  if (remainder !== Number.parseInt(cpf.charAt(10))) return false

  return true
}

// Validar data de nascimento
exports.validateBirthDate = (birthDate) => {
  const date = new Date(birthDate)
  const now = new Date()

  // Verificar se a data é válida
  if (isNaN(date.getTime())) return false

  // Verificar se a data não é no futuro
  if (date > now) return false

  // Verificar se a pessoa tem pelo menos 13 anos
  const thirteenYearsAgo = new Date()
  thirteenYearsAgo.setFullYear(now.getFullYear() - 13)

  return date <= thirteenYearsAgo
}

// Validar CEP
exports.validateZipCode = (zipCode) => {
  zipCode = zipCode.replace(/[^\d]/g, "")
  return zipCode.length === 8
}

// Validar telefone
exports.validatePhone = (phone) => {
  phone = phone.replace(/[^\d]/g, "")
  return phone.length >= 10 && phone.length <= 11
}
