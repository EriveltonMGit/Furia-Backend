const admin = require("firebase-admin")
const dotenv = require("dotenv")

dotenv.config()

// Verificar se as variáveis de ambiente estão definidas
const serviceAccount = {
  type: process.env.FIREBASE_TYPE,
  project_id: process.env.FIREBASE_PROJECT_ID,
  private_key_id: process.env.FIREBASE_PRIVATE_KEY_ID,
  private_key: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, "\n"),
  client_email: process.env.FIREBASE_CLIENT_EMAIL,
  client_id: process.env.FIREBASE_CLIENT_ID,
  auth_uri: process.env.FIREBASE_AUTH_URI,
  token_uri: process.env.FIREBASE_TOKEN_URI,
  auth_provider_x509_cert_url: process.env.FIREBASE_AUTH_PROVIDER_CERT_URL,
  client_x509_cert_url: process.env.FIREBASE_CLIENT_CERT_URL,
}

// Inicializar o Firebase Admin
let firebaseApp
try {
  firebaseApp = admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  })
  console.log("Firebase Admin inicializado com sucesso")
} catch (error) {
  console.error("Erro ao inicializar Firebase Admin:", error)
}

// Obter referência ao Firestore
const db = admin.firestore()

// Função para conectar ao banco de dados
const connectDB = async () => {
  try {
    // Verificar a conexão com o Firestore
    await db.listCollections()
    console.log("Conectado ao banco de dados Firebase Firestore")

    // Inicializar o banco de dados com as coleções necessárias
    await initializeDatabase()
  } catch (error) {
    console.error("Erro ao conectar ao banco de dados Firebase:", error)
    process.exit(1)
  }
}

// Função para inicializar o banco de dados com as coleções necessárias
const initializeDatabase = async () => {
  try {
    // No Firestore, não precisamos criar coleções explicitamente
    // Elas são criadas automaticamente quando documentos são adicionados
    console.log("Banco de dados Firebase pronto para uso")
  } catch (error) {
    console.error("Erro ao inicializar o banco de dados Firebase:", error)
    throw error
  }
}

// Exportar as funções e objetos necessários
module.exports = {
  admin,
  db,
  connectDB,
}
