import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

// Rotas que requerem autenticação
const protectedRoutes = [
  "/dashboard",
  "/profile",
  "/settings",
  // Adicione outras rotas protegidas aqui
]

// Rotas que só podem ser acessadas quando NÃO autenticado
const authRoutes = [
  "/login",
  "/register",
  "/forgot-password",
  // Adicione outras rotas de autenticação aqui
]

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Verifica se há um cookie JWT
  const hasCookie = request.cookies.has("jwt")

  // Redireciona usuários não autenticados para o login
  if (protectedRoutes.some((route) => pathname.startsWith(route)) && !hasCookie) {
    const url = new URL("/login", request.url)
    url.searchParams.set("from", pathname)
    return NextResponse.redirect(url)
  }

  // Redireciona usuários autenticados para o dashboard se tentarem acessar páginas de login/registro
  if (authRoutes.some((route) => pathname.startsWith(route)) && hasCookie) {
    return NextResponse.redirect(new URL("/dashboard", request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public files (public assets)
     * - api routes
     */
    "/((?!_next/static|_next/image|favicon.ico|public|api).*)",
  ],
}
