const { verifyToken } = require("../config/jwt")
const { db } = require("../config/firebase")

// Middleware para proteger rotas
exports.protect = async (req, res, next) => {
  try {
    let token

    // 1) Verificar se o token está presente nos cookies
    if (req.cookies.jwt) {
      token = req.cookies.jwt
    }
    // Opcional: Manter verificação no header Authorization como fallback
    else if (req.headers.authorization?.startsWith("Bearer")) {
      token = req.headers.authorization.split(" ")[1]
    }

    // 2) Verificar se o token existe
    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Acesso não autorizado. Token não fornecido.",
      })
    }

    // 3) Verificar token
    const decoded = verifyToken(token)

    if (!decoded) {
      return res.status(401).json({
        success: false,
        message: "Token inválido ou expirado",
      })
    }

    // 4) Verificar se o usuário existe
    const userDoc = await db.collection("users").doc(decoded.id).get()

    if (!userDoc.exists) {
      return res.status(401).json({
        success: false,
        message: "O usuário associado a este token não existe mais",
      })
    }

    // 5) Adicionar usuário ao objeto de requisição
    req.user = { id: userDoc.id, ...userDoc.data() }
    next()
  } catch (error) {
    console.error("Erro no middleware de autenticação:", error)
    res.status(401).json({
      success: false,
      message: "Acesso não autorizado",
      error: process.env.NODE_ENV === "development" ? error.message : undefined,
    })
  }
}

// Middleware para restringir acesso por função
exports.authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: "Acesso não autorizado",
      })
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: "Acesso proibido. Você não tem permissão para acessar este recurso.",
      })
    }

    next()
  }
}
