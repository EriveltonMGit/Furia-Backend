const bcrypt = require("bcryptjs")
const { db } = require("../config/firebase")
const { generateToken } = require("../config/jwt")
const { validateEmail, validatePassword } = require("../utils/validation")

// Define cookie options
const cookieExpiresDays = Number.parseInt(process.env.JWT_COOKIE_EXPIRES_IN, 10)
const expiresDate = new Date(Date.now() + (cookieExpiresDays || 90) * 24 * 60 * 60 * 1000)

const cookieOptions = {
  expires: expiresDate,
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "lax", // Ajuda a prevenir ataques CSRF
}

// Registrar um novo usuário
exports.register = async (req, res) => {
  try {
    const { name, email, password } = req.body

    // Validar campos
    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: "Por favor, preencha todos os campos obrigatórios",
      })
    }

    // Validar email
    if (!validateEmail(email)) {
      return res.status(400).json({
        success: false,
        message: "Email inválido",
      })
    }

    // Validar senha
    if (!validatePassword(password)) {
      return res.status(400).json({
        success: false,
        message: "A senha deve ter pelo menos 8 caracteres, incluindo letras e números",
      })
    }

    // Verificar se o email já está em uso
    const userSnapshot = await db.collection("users").where("email", "==", email).get()

    if (!userSnapshot.empty) {
      return res.status(400).json({
        success: false,
        message: "Este email já está em uso",
      })
    }

    // Hash da senha
    const salt = await bcrypt.genSalt(10)
    const hashedPassword = await bcrypt.hash(password, salt)

    // Criar timestamp para created_at e updated_at
    const now = new Date()

    // Inserir usuário no Firestore
    const userRef = db.collection("users").doc()
    const userId = userRef.id

    // Criar o usuário com todos os dados
    await userRef.set({
      name,
      email,
      password: hashedPassword,
      role: "user",
      created_at: now,
      updated_at: now,
    })

    // Criar perfil do usuário
    await db.collection("profiles").doc(userId).set({
      user_id: userId,
      verification_status: "pending",
      fan_level: "Beginner",
      fan_points: 0,
      created_at: now,
      updated_at: now,
    })

    // Criar interesses
    await db.collection("interests").doc(userId).set({
      user_id: userId,
      favorite_games: [],
      favorite_teams: [],
      followed_players: [],
      preferred_platforms: [],
      created_at: now,
      updated_at: now,
    })

    // Criar atividades
    await db.collection("activities").doc(userId).set({
      user_id: userId,
      events_attended: [],
      purchased_merchandise: [],
      subscriptions: [],
      competitions_participated: [],
      created_at: now,
      updated_at: now,
    })

    // Criar conexões sociais
    await db.collection("social_connections").doc(userId).set({
      user_id: userId,
      twitter: false,
      instagram: false,
      facebook: false,
      discord: false,
      twitch: false,
      other_profiles: [],
      created_at: now,
      updated_at: now,
    })

    // Gerar token JWT
    const token = generateToken(userId)

    // Definir o cookie HTTP
    res.cookie("jwt", token, cookieOptions)

    // Retornar resposta de sucesso
    res.status(201).json({
      success: true,
      message: "Usuário registrado com sucesso",
      user: {
        id: userId,
        name,
        email,
        role: "user",
      },
    })
  } catch (error) {
    console.error("Erro ao registrar usuário:", error)
    res.status(500).json({
      success: false,
      message: "Erro ao registrar usuário",
      error: process.env.NODE_ENV === "development" ? error.message : undefined,
    })
  }
}

// Login de usuário
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body

    // Validar campos
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Por favor, forneça email e senha",
      })
    }

    // Buscar usuário pelo email
    const userSnapshot = await db.collection("users").where("email", "==", email).get()

    if (userSnapshot.empty) {
      return res.status(401).json({
        success: false,
        message: "Credenciais inválidas",
      })
    }

    // Obter o primeiro documento (deve ser único devido à restrição de email)
    const userDoc = userSnapshot.docs[0]
    const user = { id: userDoc.id, ...userDoc.data() }

    // Verificar senha
    const isMatch = await bcrypt.compare(password, user.password)

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: "Credenciais inválidas",
      })
    }

    // Gerar token JWT
    const token = generateToken(user.id)

    // Definir o cookie HTTP
    res.cookie("jwt", token, cookieOptions)

    // Retornar resposta de sucesso
    res.status(200).json({
      success: true,
      message: "Login realizado com sucesso",
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    })
  } catch (error) {
    console.error("Erro ao fazer login:", error)
    res.status(500).json({
      success: false,
      message: "Erro ao fazer login",
      error: process.env.NODE_ENV === "development" ? error.message : undefined,
    })
  }
}

// Obter usuário atual
exports.getMe = async (req, res) => {
  try {
    const userId = req.user.id

    // Buscar usuário pelo ID
    const userDoc = await db.collection("users").doc(userId).get()

    if (!userDoc.exists) {
      return res.status(404).json({
        success: false,
        message: "Usuário não encontrado",
      })
    }

    const userData = userDoc.data()

    // Remover a senha do objeto antes de enviar
    const { password, ...userWithoutPassword } = userData

    // Retornar resposta de sucesso
    res.status(200).json({
      success: true,
      user: {
        id: userDoc.id,
        ...userWithoutPassword,
      },
    })
  } catch (error) {
    console.error("Erro ao obter usuário atual:", error)
    res.status(500).json({
      success: false,
      message: "Erro ao obter usuário atual",
      error: process.env.NODE_ENV === "development" ? error.message : undefined,
    })
  }
}

// Função para fazer logout
exports.logout = (req, res) => {
  try {
    const cookieOptions = {
      expires: new Date(Date.now() + 10 * 1000), // Expira em 10 segundos
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
    }

    res.cookie("jwt", "loggedout", cookieOptions)

    res.status(200).json({
      success: true,
      message: "Logout realizado com sucesso",
    })
  } catch (error) {
    console.error("Erro ao fazer logout:", error)
    res.status(500).json({
      success: false,
      message: "Erro interno ao fazer logout",
      error: process.env.NODE_ENV === "development" ? error.message : undefined,
    })
  }
}
