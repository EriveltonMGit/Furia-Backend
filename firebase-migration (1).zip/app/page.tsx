"use client"

import { LogoutButton } from "../components/logout-button"

export default function SyntheticV0PageForDeployment() {
  return <LogoutButton />
}