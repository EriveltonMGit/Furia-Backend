"use client"

import { useEffect, useState, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "../contexts/AuthContext"
import { Loader2 } from "lucide-react"

interface ProtectedRouteProps {
  children: ReactNode
}

export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { checkAuth, loading } = useAuth()
  const router = useRouter()
  const [isChecking, setIsChecking] = useState(true)

  useEffect(() => {
    const verifyAuth = async () => {
      if (!loading) {
        try {
          const isAuthenticated = await checkAuth()
          if (!isAuthenticated) {
            router.push("/login")
          }
        } catch (error) {
          console.error("Erro ao verificar autenticação:", error)
          router.push("/login")
        } finally {
          setIsChecking(false)
        }
      }
    }

    verifyAuth()
  }, [checkAuth, router, loading])

  if (loading || isChecking) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-[#00FF00]" />
      </div>
    )
  }

  return <>{children}</>
}
